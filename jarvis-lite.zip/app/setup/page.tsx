import SetupGuide from "@/app/components/setup-guide"

export default function SetupPage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 text-white">
      <div className="container mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold mb-4 bg-gradient-to-r from-cyan-400 to-blue-400 bg-clip-text text-transparent">
            JARVIS Setup Guide
          </h1>
          <p className="text-xl text-slate-300">Get your own Google Maps API key in 5 minutes</p>
        </div>
        <SetupGuide />
      </div>
    </div>
  )
}
