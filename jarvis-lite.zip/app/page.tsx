"use client"

import { useState, useRef, useEffect, useCallback } from "react"
import {
  Mic,
  MicOff,
  Zap,
  Volume2,
  AlertCircle,
  Settings,
  MapPin,
  Wifi,
  WifiOff,
  Search,
  Activity,
  Cpu,
  VolumeX,
} from "lucide-react"
import { Alert, AlertDescription } from "@/components/ui/alert"
import {
  ParticleField,
  MatrixRain,
  HolographicDisplay,
  EnergyCore,
  HUDStatusBar,
  CircuitPattern,
  DataStream,
  GlitchText,
  HolographicScanner,
} from "@/app/components/futuristic-ui"

export default function JarvisLite() {
  const [isListening, setIsListening] = useState(false)
  const [wakeWordDetected, setWakeWordDetected] = useState(false)
  const [userSpeech, setUserSpeech] = useState("")
  const [aiResponse, setAiResponse] = useState("")
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [isProcessing, setIsProcessing] = useState(false)
  const [isMuted, setIsMuted] = useState(false) // New state for mute
  const [conversationHistory, setConversationHistory] = useState<Array<{ role: string; content: string }>>([])
  const [configurationStatus, setConfigurationStatus] = useState({
    openai: false,
    serper: false,
    googleMaps: false,
    checked: false,
  })
  const [networkStatus, setNetworkStatus] = useState({
    online: navigator.onLine,
    speechAvailable: false,
  })
  const [errorMessage, setErrorMessage] = useState("")
  const [systemStats, setSystemStats] = useState({
    cpuUsage: 45,
    memoryUsage: 67,
    networkLatency: 23,
    aiConfidence: 89,
  })

  const audioRef = useRef<HTMLAudioElement>(null)
  const wakeWordRecognitionRef = useRef<any | null>(null)
  const voiceInputRecognitionRef = useRef<any | null>(null)
  const interruptionRecognitionRef = useRef<any | null>(null) // New ref for interruption listener
  const isWakeWordActiveRef = useRef(false)
  const isVoiceInputActiveRef = useRef(false)
  const isInterruptionActiveRef = useRef(false) // New ref for interruption listener active state
  const wakeWordTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const voiceInputTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const reconnectTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const errorCountRef = useRef(0)

  // New: Stop interruption recognition
  const stopInterruptionRecognition = useCallback(() => {
    if (interruptionRecognitionRef.current && isInterruptionActiveRef.current) {
      try {
        interruptionRecognitionRef.current.stop()
      } catch (error) {
        console.log("Interruption recognition already stopped.")
      }
      isInterruptionActiveRef.current = false
    }
  }, [])

  // Simulate system stats updates
  useEffect(() => {
    const interval = setInterval(() => {
      setSystemStats((prev) => ({
        cpuUsage: Math.max(20, Math.min(90, prev.cpuUsage + (Math.random() - 0.5) * 10)),
        memoryUsage: Math.max(30, Math.min(85, prev.memoryUsage + (Math.random() - 0.5) * 8)),
        networkLatency: Math.max(10, Math.min(100, prev.networkLatency + (Math.random() - 0.5) * 15)),
        aiConfidence: Math.max(70, Math.min(99, prev.aiConfidence + (Math.random() - 0.5) * 5)),
      }))
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Monitor network status
  useEffect(() => {
    const handleOnline = () => {
      setNetworkStatus((prev) => ({ ...prev, online: true }))
      setErrorMessage("")
      console.log("Network connection restored")

      // Restart wake word recognition after network recovery
      setTimeout(() => {
        if (!isProcessing && !isSpeaking && !isListening) {
          startWakeWordRecognition()
        }
      }, 2000)
    }

    const handleOffline = () => {
      setNetworkStatus((prev) => ({ ...prev, online: false }))
      setErrorMessage("Network connection lost. Voice recognition may not work.")
      console.log("Network connection lost")

      // Stop all recognition when offline
      stopWakeWordRecognition()
      stopVoiceInputRecognition()
      stopInterruptionRecognition() // Stop interruption listener too
    }

    window.addEventListener("online", handleOnline)
    window.addEventListener("offline", handleOffline)

    return () => {
      window.removeEventListener("online", handleOnline)
      window.removeEventListener("offline", handleOffline)
    }
  }, [isProcessing, isSpeaking, isListening])

  // Check speech recognition availability
  const checkSpeechRecognitionAvailability = useCallback(() => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    const available = !!SpeechRecognition && navigator.onLine

    setNetworkStatus((prev) => ({ ...prev, speechAvailable: available }))

    if (!available) {
      if (!SpeechRecognition) {
        setErrorMessage("Speech recognition is not supported in this browser. Try Chrome or Edge.")
      } else if (!navigator.onLine) {
        setErrorMessage("Speech recognition requires an internet connection.")
      }
    } else {
      setErrorMessage("")
    }

    return available
  }, [])

  // Check API configuration status
  const checkConfiguration = async () => {
    try {
      // Get configuration from server
      const configResponse = await fetch("/api/config")
      const serverConfig = await configResponse.json()

      // Test OpenAI with a simple request
      const openaiTest = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: "Hello",
          searchResults: "",
          history: [],
        }),
      })
      const openaiData = await openaiTest.json()
      const openaiWorking = !openaiData.error || openaiData.error !== "missing_api_key"

      // Test Serper API by making a simple search request
      let serperWorking = false
      if (serverConfig.serper) {
        try {
          const serperTest = await fetch("/api/search", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ query: "test", type: "search" }), // Use type "search" for test
          })
          const serperData = await serperTest.json()
          serperWorking = serperData.available === true

          if (!serperWorking && serperData.error) {
            console.warn("Serper API test failed:", serperData.error)
          }
        } catch (error) {
          console.warn("Serper API test error:", error)
          serperWorking = false
        }
      }

      // Test Google Maps API
      let googleMapsWorking = false
      if (serverConfig.googleMaps) {
        try {
          const mapsTest = await fetch("/api/maps", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ test: true }),
          })
          const mapsData = await mapsTest.json()
          googleMapsWorking = mapsData.available === true

          if (!googleMapsWorking && mapsData.error) {
            console.warn("Google Maps API test failed:", mapsData.error)
          }
        } catch (error) {
          console.warn("Google Maps API test error:", error)
          googleMapsWorking = false
        }
      }

      setConfigurationStatus({
        openai: openaiWorking,
        serper: serperWorking,
        googleMaps: googleMapsWorking,
        checked: true,
      })

      console.log("Configuration check completed:", {
        openai: openaiWorking,
        serper: serperWorking,
        googleMaps: googleMapsWorking,
      })
    } catch (error) {
      console.error("Configuration check failed:", error)
      setConfigurationStatus({
        openai: false,
        serper: false,
        googleMaps: false,
        checked: true,
      })
    }
  }

  // Play activation sound
  const playActivationSound = () => {
    if (audioRef.current) {
      audioRef.current.play().catch(console.error)
    }
  }

  // Stop wake word recognition
  const stopWakeWordRecognition = useCallback(() => {
    if (wakeWordRecognitionRef.current && isWakeWordActiveRef.current) {
      try {
        wakeWordRecognitionRef.current.stop()
      } catch (error) {
        console.log("Wake word recognition already stopped")
      }
      isWakeWordActiveRef.current = false
    }
    if (wakeWordTimeoutRef.current) {
      clearTimeout(wakeWordTimeoutRef.current)
      wakeWordTimeoutRef.current = null
    }
    if (reconnectTimeoutRef.current) {
      clearTimeout(reconnectTimeoutRef.current)
      reconnectTimeoutRef.current = null
    }
  }, [])

  // Stop voice input recognition
  const stopVoiceInputRecognition = useCallback(() => {
    if (voiceInputRecognitionRef.current && isVoiceInputActiveRef.current) {
      try {
        voiceInputRecognitionRef.current.stop()
      } catch (error) {
        console.log("Voice input recognition already stopped")
      }
      isVoiceInputActiveRef.current = false
    }
    if (voiceInputTimeoutRef.current) {
      clearTimeout(voiceInputTimeoutRef.current)
      voiceInputTimeoutRef.current = null
    }
  }, [])

  // New: Start interruption recognition
  const startInterruptionRecognition = useCallback(() => {
    if (isInterruptionActiveRef.current) {
      return
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition
    if (!SpeechRecognition) {
      console.warn("Speech recognition not supported for interruption.")
      return
    }

    try {
      const recognition = new SpeechRecognition()
      recognition.continuous = true // Keep listening
      recognition.interimResults = true // Get results quickly
      recognition.lang = "en-US"

      recognition.onstart = () => {
        isInterruptionActiveRef.current = true
        console.log("Interruption recognition started.")
      }

      recognition.onresult = (event) => {
        const lastResult = event.results[event.results.length - 1]
        const transcript = lastResult[0].transcript.toLowerCase().trim()

        // Check for mute commands
        if (transcript.includes("mute") || transcript.includes("be quiet") || transcript.includes("silence")) {
          console.log("Mute command detected:", transcript)
          if ("speechSynthesis" in window) {
            speechSynthesis.cancel()
          }
          setIsSpeaking(false)
          setIsMuted(true)
          setAiResponse("Voice output muted.") // Provide immediate feedback
          stopInterruptionRecognition() // Stop this listener once command is handled
          // Optionally, restart wake word if not already active and not processing
          if (!isProcessing && !isListening && !isWakeWordActiveRef.current) {
            startWakeWordRecognition()
          }
          return
        }

        // Check for stop/cancel commands
        if (transcript.includes("stop") || transcript.includes("cancel") || transcript.includes("abort")) {
          console.log("Stop command detected:", transcript)
          if ("speechSynthesis" in window) {
            speechSynthesis.cancel()
          }
          setIsSpeaking(false)
          setIsProcessing(false)
          stopVoiceInputRecognition() // Stop main voice input if active
          setAiResponse("Command stopped.") // Provide immediate feedback
          stopInterruptionRecognition() // Stop this listener once command is handled
          // Optionally, restart wake word if not already active and not processing
          if (!isProcessing && !isListening && !isWakeWordActiveRef.current) {
            startWakeWordRecognition()
          }
          return
        }
      }

      recognition.onerror = (event) => {
        console.error("Interruption recognition error:", event.error)
        isInterruptionActiveRef.current = false
        // Attempt to restart if not aborted and still speaking
        if (event.error !== "aborted" && isSpeaking) {
          setTimeout(() => startInterruptionRecognition(), 1000)
        }
      }

      recognition.onend = () => {
        console.log("Interruption recognition ended.")
        isInterruptionActiveRef.current = false
        // Restart if JARVIS is still speaking
        if (isSpeaking) {
          setTimeout(() => startInterruptionRecognition(), 500)
        }
      }

      interruptionRecognitionRef.current = recognition
      recognition.start()
    } catch (error) {
      console.error("Failed to start interruption recognition:", error)
      isInterruptionActiveRef.current = false
    }
  }, [isSpeaking, isProcessing, isListening])

  // Start wake word recognition with better error handling
  const startWakeWordRecognition = useCallback(() => {
    // Don't start if already active or if voice input is active or if JARVIS is speaking
    if (isWakeWordActiveRef.current || isVoiceInputActiveRef.current || isProcessing || isSpeaking) {
      return
    }

    // Check if speech recognition is available
    if (!checkSpeechRecognitionAvailability()) {
      console.warn("Speech recognition not available, skipping wake word detection")
      return
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

    try {
      const recognition = new SpeechRecognition()
      recognition.continuous = true
      recognition.interimResults = true
      recognition.lang = "en-US"

      recognition.onstart = () => {
        isWakeWordActiveRef.current = true
        errorCountRef.current = 0 // Reset error count on successful start
        console.log("Wake word recognition started")
      }

      recognition.onresult = (event) => {
        const lastResult = event.results[event.results.length - 1]
        if (lastResult.isFinal) {
          const transcript = lastResult[0].transcript.toLowerCase().trim()
          if (transcript.includes("jarvis")) {
            console.log("Wake word detected:", transcript)
            setWakeWordDetected(true)
            setIsListening(true)
            playActivationSound()
            stopWakeWordRecognition()
            setTimeout(() => setWakeWordDetected(false), 3000)
          }
        }
      }

      recognition.onerror = (event) => {
        console.error("Wake word recognition error:", event.error)
        isWakeWordActiveRef.current = false
        errorCountRef.current += 1

        // Handle different types of errors
        switch (event.error) {
          case "network":
            setErrorMessage("Network error in speech recognition. Checking connection...")
            // Check network status and retry with exponential backoff
            if (navigator.onLine && errorCountRef.current < 5) {
              const retryDelay = Math.min(1000 * Math.pow(2, errorCountRef.current), 10000)
              console.log(`Retrying wake word recognition in ${retryDelay}ms`)
              reconnectTimeoutRef.current = setTimeout(() => {
                startWakeWordRecognition()
              }, retryDelay)
            } else {
              setErrorMessage("Speech recognition unavailable. Please check your internet connection.")
            }
            break

          case "not-allowed":
            setErrorMessage("Microphone access denied. Please allow microphone permissions.")
            break

          case "service-not-allowed":
            setErrorMessage("Speech recognition service not allowed. Please check browser settings.")
            break

          case "bad-grammar":
          case "language-not-supported":
            setErrorMessage("Speech recognition language not supported.")
            break

          case "no-speech":
            // This is normal, just restart
            if (errorCountRef.current < 3) {
              wakeWordTimeoutRef.current = setTimeout(() => {
                startWakeWordRecognition()
              }, 1000)
            }
            break

          default:
            if (event.error !== "aborted" && errorCountRef.current < 3) {
              // Generic retry for other errors
              wakeWordTimeoutRef.current = setTimeout(() => {
                startWakeWordRecognition()
              }, 2000)
            }
        }
      }

      recognition.onend = () => {
        console.log("Wake word recognition ended")
        isWakeWordActiveRef.current = false

        // Only restart if conditions are right and we haven't had too many errors
        if (!isProcessing && !isSpeaking && !isVoiceInputActiveRef.current && errorCountRef.current < 5) {
          wakeWordTimeoutRef.current = setTimeout(() => {
            startWakeWordRecognition()
          }, 1000)
        }
      }

      wakeWordRecognitionRef.current = recognition
      recognition.start()
    } catch (error) {
      console.error("Failed to start wake word recognition:", error)
      isWakeWordActiveRef.current = false
      setErrorMessage("Failed to initialize speech recognition.")
    }
  }, [isProcessing, isSpeaking, stopWakeWordRecognition, checkSpeechRecognitionAvailability])

  // Start voice input recognition with better error handling
  const startVoiceInputRecognition = useCallback(() => {
    if (isVoiceInputActiveRef.current) {
      console.log("Voice input already active")
      return
    }

    // Stop wake word recognition first
    stopWakeWordRecognition()
    stopInterruptionRecognition() // Stop interruption listener when main voice input starts

    // Check if speech recognition is available
    if (!checkSpeechRecognitionAvailability()) {
      console.warn("Speech recognition not available")
      setIsListening(false)
      return
    }

    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition

    try {
      const recognition = new SpeechRecognition()
      recognition.continuous = false
      recognition.interimResults = true
      recognition.lang = "en-US"

      recognition.onstart = () => {
        isVoiceInputActiveRef.current = true
        console.log("Voice input recognition started")
      }

      recognition.onresult = (event) => {
        let finalTranscript = ""
        let interimTranscript = ""

        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript
          } else {
            interimTranscript += event.results[i][0].transcript
          }
        }

        if (finalTranscript.trim()) {
          handleVoiceInput(finalTranscript.trim())
          stopVoiceInputRecognition()
          setIsListening(false)
          return
        }

        // Reset timeout on any speech activity (including interim results)
        if (voiceInputTimeoutRef.current) {
          clearTimeout(voiceInputTimeoutRef.current)
        }

        // If we have interim results, extend the timeout
        if (interimTranscript.trim()) {
          console.log("Interim speech detected, extending timeout")
          voiceInputTimeoutRef.current = setTimeout(() => {
            console.log("Voice input timeout - no final speech detected")
            stopVoiceInputRecognition()
            setIsListening(false)
          }, 6000) // Extended timeout when speech is detected
        } else {
          // Standard timeout when no speech activity
          voiceInputTimeoutRef.current = setTimeout(() => {
            console.log("Voice input timeout - no speech activity")
            stopVoiceInputRecognition()
            setIsListening(false)
          }, 4000)
        }
      }

      recognition.onerror = (event) => {
        console.error("Voice input recognition error:", event.error)
        isVoiceInputActiveRef.current = false

        switch (event.error) {
          case "no-speech":
            // This is normal - user didn't speak within timeout
            console.log("No speech detected, ending voice input session")
            setIsListening(false)
            // Don't show error message for no-speech, it's expected behavior
            break

          case "not-allowed":
            setErrorMessage("Microphone access denied. Please allow microphone permissions.")
            setIsListening(false)
            break

          case "network":
            setErrorMessage("Network error during voice input. Please check your connection and try again.")
            setIsListening(false)
            break

          case "audio-capture":
            setErrorMessage("Microphone not available. Please check your microphone connection.")
            setIsListening(false)
            break

          case "service-not-allowed":
            setErrorMessage("Speech recognition service not allowed. Please check browser settings.")
            setIsListening(false)
            break

          case "aborted":
            // Normal when user stops listening manually
            console.log("Voice input aborted by user")
            setIsListening(false)
            break

          default:
            console.log(`Voice input error: ${event.error}`)
            setErrorMessage("Voice recognition error. Please try again.")
            setIsListening(false)
        }
      }

      recognition.onend = () => {
        console.log("Voice input recognition ended")
        isVoiceInputActiveRef.current = false
        setIsListening(false)
      }

      voiceInputRecognitionRef.current = recognition
      recognition.start()
    } catch (error) {
      console.error("Failed to start voice input recognition:", error)
      isVoiceInputActiveRef.current = false
      setIsListening(false)
      setErrorMessage("Failed to start voice input.")
    }
  }, [stopWakeWordRecognition, stopInterruptionRecognition, checkSpeechRecognitionAvailability])

  // Handle voice input completion
  const handleVoiceInput = async (transcript: string) => {
    if (!transcript.trim()) return

    setUserSpeech(transcript)
    setIsProcessing(true)
    setErrorMessage("") // Clear any previous errors

    try {
      // Add user message to history
      const newHistory = [...conversationHistory, { role: "user", content: transcript }]

      // Check for direct commands first (for when main voice input is active)
      const commandResult = handleDirectCommands(transcript)
      if (commandResult.handled) {
        setAiResponse(commandResult.response)
        setConversationHistory([...newHistory, { role: "assistant", content: commandResult.response }])
        await speakResponse(commandResult.response)
        return // Stop further processing for direct commands
      }

      // If not a direct command, proceed with AI/search/maps
      const requestType = await analyzeRequest(transcript)
      let searchResults = ""
      let mapsResults = ""

      // Handle different types of requests
      if (requestType.needsSearch && configurationStatus.serper) {
        searchResults = await performSearch(transcript, requestType.searchType) // Pass searchType
      }

      if (requestType.needsMaps && configurationStatus.googleMaps) {
        mapsResults = await performMapsQuery(transcript, requestType.mapsType)
      }

      // Combine results for AI context
      let combinedResults = ""
      if (searchResults) combinedResults += `Web Search Results:\n${searchResults}\n\n`
      if (mapsResults) combinedResults += `Maps Results:\n${mapsResults}\n\n`

      // Get AI response
      const response = await getAIResponse(transcript, combinedResults, newHistory)
      setAiResponse(response)

      // Update conversation history
      setConversationHistory([...newHistory, { role: "assistant", content: response }])

      // Speak the response
      await speakResponse(response)
    } catch (error) {
      console.error("Error processing voice input:", error)
      const errorMsg = "Sorry, I encountered an error processing your request."
      setAiResponse(errorMsg)
      await speakResponse(errorMsg)
    } finally {
      setIsProcessing(false)
    }
  }

  // Handle direct commands like mute/unmute/stop (for when main voice input is active)
  const handleDirectCommands = (query: string) => {
    const lowerQuery = query.toLowerCase()
    let handled = false
    let response = ""

    if (lowerQuery.includes("mute") || lowerQuery.includes("be quiet") || lowerQuery.includes("silence")) {
      setIsMuted(true)
      response = "Voice output muted."
      handled = true
      if ("speechSynthesis" in window) {
        speechSynthesis.cancel() // Immediately stop any ongoing speech
      }
    } else if (lowerQuery.includes("unmute") || lowerQuery.includes("speak") || lowerQuery.includes("talk")) {
      setIsMuted(false)
      response = "Voice output re-enabled."
      handled = true
    } else if (lowerQuery.includes("stop") || lowerQuery.includes("cancel") || lowerQuery.includes("abort")) {
      setIsProcessing(false) // Stop processing state
      setIsSpeaking(false) // Stop speaking state
      stopVoiceInputRecognition() // Ensure voice input is stopped
      if ("speechSynthesis" in window) {
        speechSynthesis.cancel() // Immediately stop any ongoing speech
      }
      response = "Command stopped."
      handled = true
    }

    return { handled, response }
  }

  // Analyze what type of request the user is making
  const analyzeRequest = async (
    query: string,
  ): Promise<{
    needsSearch: boolean
    searchType: "search" | "news" // Added searchType
    needsMaps: boolean
    mapsType: string
  }> => {
    const lowerQuery = query.toLowerCase()

    // Maps-related keywords
    const mapsKeywords = {
      search: ["find", "locate", "where is", "address of", "location of"],
      directions: ["directions to", "how to get to", "route to", "navigate to", "drive to", "walk to"],
      nearby: ["near me", "nearby", "close to", "around"],
    }

    // Web search keywords
    const searchKeywords = [
      "current",
      "latest",
      "today",
      "now",
      "recent",
      "what is",
      "who is",
      "when did",
      "price of",
      "stock",
      "define",
    ]

    // News-specific keywords
    const newsKeywords = ["news", "latest news", "headlines", "breaking news", "what's happening"]

    let needsMaps = false
    let mapsType = "search"
    let needsSearch = false
    let searchType: "search" | "news" = "search" // Default search type

    // Check for maps requests
    if (mapsKeywords.directions.some((keyword) => lowerQuery.includes(keyword))) {
      needsMaps = true
      mapsType = "directions"
    } else if (mapsKeywords.nearby.some((keyword) => lowerQuery.includes(keyword))) {
      needsMaps = true
      mapsType = "nearby"
    } else if (mapsKeywords.search.some((keyword) => lowerQuery.includes(keyword))) {
      needsMaps = true
      mapsType = "search"
    }

    // Check for news requests (if not a maps request)
    if (!needsMaps && newsKeywords.some((keyword) => lowerQuery.includes(keyword))) {
      needsSearch = true
      searchType = "news"
    }
    // Check for general web search requests (if not a maps or news request)
    else if (!needsMaps && searchKeywords.some((keyword) => lowerQuery.includes(keyword))) {
      needsSearch = true
      searchType = "search"
    }

    return { needsSearch, searchType, needsMaps, mapsType }
  }

  // Perform web search
  const performSearch = async (query: string, type: "search" | "news"): Promise<string> => {
    try {
      const response = await fetch("/api/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, type }), // Pass type to API route
      })
      const data = await response.json()
      return data.results || ""
    } catch (error) {
      console.error("Search error:", error)
      return ""
    }
  }

  // Perform Google Maps query
  const performMapsQuery = async (query: string, type: string): Promise<string> => {
    try {
      const response = await fetch("/api/maps", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query, type }),
      })
      const data = await response.json()
      return data.results || ""
    } catch (error) {
      console.error("Maps error:", error)
      return ""
    }
  }

  // Get AI response
  const getAIResponse = async (
    query: string,
    searchResults: string,
    history: Array<{ role: string; content: string }>,
  ): Promise<string> => {
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          message: query,
          searchResults,
          history: history.slice(-6), // Keep last 6 messages for context
        }),
      })
      const data = await response.json()
      return data.response || "I apologize, but I could not generate a response."
    } catch (error) {
      console.error("AI response error:", error)
      return "I apologize, but I encountered an error generating a response."
    }
  }

  // Speak response - always use browser TTS for reliability
  const speakResponse = async (text: string) => {
    if (isMuted) {
      console.log("Voice output is muted. Not speaking:", text)
      setIsSpeaking(false) // Ensure speaking state is off if muted
      return
    }

    setIsSpeaking(true)
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.rate = 0.9
    utterance.pitch = 1.0
    utterance.volume = 1.0

    utterance.onend = () => {
      setIsSpeaking(false)
    }

    utterance.onerror = (event) => {
      console.error("Speech synthesis error:", event)
      setIsSpeaking(false)
    }

    // Small delay to ensure clean state
    setTimeout(() => {
      speechSynthesis.speak(utterance)
    }, 100)
  }

  // Handle manual listening toggle
  const handleListeningToggle = () => {
    if (isListening) {
      stopVoiceInputRecognition()
      setIsListening(false)
    } else {
      setErrorMessage("") // Clear any error messages
      setIsListening(true)
    }
  }

  // Effect to manage main voice input recognition
  useEffect(() => {
    if (isListening && !isVoiceInputActiveRef.current) {
      // Small delay to ensure clean state
      setTimeout(() => {
        startVoiceInputRecognition()
      }, 100)
    } else if (!isListening) {
      stopVoiceInputRecognition()
    }
  }, [isListening, startVoiceInputRecognition, stopVoiceInputRecognition])

  // Effect to manage wake word and interruption recognition
  useEffect(() => {
    // Manage wake word recognition
    const shouldRunWakeWord =
      !isProcessing && !isSpeaking && !isListening && networkStatus.online && networkStatus.speechAvailable

    if (shouldRunWakeWord && !isWakeWordActiveRef.current) {
      setTimeout(() => {
        startWakeWordRecognition()
      }, 500)
    } else if (!shouldRunWakeWord) {
      stopWakeWordRecognition()
    }

    // Manage interruption recognition
    if (isSpeaking && networkStatus.online && networkStatus.speechAvailable) {
      startInterruptionRecognition()
    } else {
      stopInterruptionRecognition()
    }
  }, [
    isProcessing,
    isSpeaking,
    isListening,
    networkStatus,
    startWakeWordRecognition,
    stopWakeWordRecognition,
    startInterruptionRecognition,
    stopInterruptionRecognition,
  ])

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopWakeWordRecognition()
      stopVoiceInputRecognition()
      stopInterruptionRecognition() // Add to cleanup
      if ("speechSynthesis" in window) {
        speechSynthesis.cancel()
      }
      if (reconnectTimeoutRef.current) {
        clearTimeout(reconnectTimeoutRef.current)
      }
    }
  }, [stopWakeWordRecognition, stopVoiceInputRecognition, stopInterruptionRecognition])

  // Check microphone permissions and configuration
  useEffect(() => {
    const checkMicrophonePermission = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
        stream.getTracks().forEach((track) => track.stop())
        return true
      } catch (error) {
        console.error("Microphone permission error:", error)
        setErrorMessage("Microphone access denied. Please allow microphone permissions to use voice features.")
        return false
      }
    }

    checkMicrophonePermission()
    checkSpeechRecognitionAvailability()

    // Delay configuration check to avoid conflicts during initialization
    setTimeout(() => {
      checkConfiguration()
    }, 1000)
  }, [checkSpeechRecognitionAvailability])

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-blue-950 to-slate-950 text-white overflow-hidden relative">
      {/* Futuristic Background Effects */}
      <div className="absolute inset-0">
        <ParticleField />
        <MatrixRain />
        <CircuitPattern />
      </div>

      {/* Animated Gradient Background */}
      <div className="absolute inset-0 opacity-30">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse"></div>
        <div className="absolute top-3/4 right-1/4 w-96 h-96 bg-gradient-to-r from-purple-500 to-cyan-500 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-1000"></div>
        <div className="absolute bottom-1/4 left-1/2 w-96 h-96 bg-gradient-to-r from-blue-500 to-purple-600 rounded-full mix-blend-multiply filter blur-xl animate-pulse delay-2000"></div>
      </div>

      {/* Audio element for activation sound */}
      <audio ref={audioRef} preload="auto">
        <source
          src="data:audio/wav;base64,UklGRnoGAABXQVZFZm10IBAAAAABAAEAQB8AAEAfAAABAAgAZGF0YQoGAACBhYqFbF1fdJivrJBhNjVgodDbq2EcBj+a2/LDciUFLIHO8tiJNwgZaLvt559NEAxQp+PwtmMcBjiR1/LMeSwFJHfH8N2QQAoUXrTp66hVFApGn+DyvmwhBSuBzvLZiTYIG2m98OScTgwOUarm7blmGgU7k9n1unEiBC13yO/eizEIHWq+8+OWT"
          type="audio/wav"
        />
      </audio>

      <div className="relative z-10 container mx-auto px-4 py-8">
        {/* Futuristic Header */}
        <div className="text-center mb-8">
          <HolographicDisplay className="inline-block p-8 mb-4">
            <h1 className="text-7xl font-bold mb-4 cyber-text font-mono tracking-wider">
              <GlitchText>J.A.R.V.I.S</GlitchText>
            </h1>
            <div className="text-xl text-cyan-300 font-mono tracking-widest">
              [ JUST A RATHER VERY INTELLIGENT SYSTEM ]
            </div>
            <div className="text-sm text-cyan-500 mt-2 font-mono">NEURAL INTERFACE v2.1.7 | STATUS: ONLINE</div>
          </HolographicDisplay>
        </div>

        {/* System Status HUD */}
        <div className="max-w-6xl mx-auto mb-8">
          <HolographicDisplay className="p-6">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              <HUDStatusBar label="CPU USAGE" value={systemStats.cpuUsage} color="cyan" />
              <HUDStatusBar label="MEMORY" value={systemStats.memoryUsage} color="green" />
              <HUDStatusBar label="LATENCY" value={systemStats.networkLatency} maxValue={100} color="yellow" />
              <HUDStatusBar label="AI CONFIDENCE" value={systemStats.aiConfidence} color="purple" />
            </div>

            <div className="flex items-center justify-center gap-8 text-sm font-mono">
              <div className="flex items-center gap-2">
                {networkStatus.online ? (
                  <Wifi className="w-4 h-4 text-green-400 status-indicator" />
                ) : (
                  <WifiOff className="w-4 h-4 text-red-400 status-indicator" />
                )}
                <span>NETWORK: {networkStatus.online ? "CONNECTED" : "OFFLINE"}</span>
              </div>
              <div className="flex items-center gap-2">
                <div
                  className={`w-3 h-3 rounded-full status-indicator ${networkStatus.speechAvailable ? "bg-green-400" : "bg-red-400"}`}
                ></div>
                <span>SPEECH: {networkStatus.speechAvailable ? "ACTIVE" : "INACTIVE"}</span>
              </div>
              <div className="flex items-center gap-2">
                <Activity className="w-4 h-4 text-cyan-400 status-indicator" />
                <span>NEURAL CORE: OPERATIONAL</span>
              </div>
            </div>
          </HolographicDisplay>
        </div>

        {/* Error Messages */}
        {errorMessage && (
          <div className="max-w-4xl mx-auto mb-8">
            <HolographicDisplay className="border-red-500/50">
              <Alert className="border-red-500/30 bg-red-900/20">
                <AlertCircle className="h-4 w-4" />
                <AlertDescription className="font-mono">[ERROR] {errorMessage}</AlertDescription>
              </Alert>
            </HolographicDisplay>
          </div>
        )}

        {/* Configuration Status */}
        {configurationStatus.checked && (
          <div className="max-w-4xl mx-auto mb-8">
            <HolographicDisplay className="p-6">
              <div className="flex items-center gap-2 mb-4">
                <Settings className="w-5 h-5 text-cyan-400" />
                <h3 className="text-lg font-semibold text-cyan-400 font-mono">SYSTEM MODULES</h3>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="flex items-center gap-2 p-3 hud-element rounded">
                  <div
                    className={`w-3 h-3 rounded-full status-indicator ${configurationStatus.openai ? "bg-green-400" : "bg-red-400"}`}
                  ></div>
                  <Cpu className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-mono">AI CORE {configurationStatus.openai ? "✓" : "✗"}</span>
                </div>
                <div className="flex items-center gap-2 p-3 hud-element rounded">
                  <div
                    className={`w-3 h-3 rounded-full status-indicator ${configurationStatus.serper ? "bg-green-400" : "bg-red-400"}`}
                  ></div>
                  <Search className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-mono">WEB SEARCH {configurationStatus.serper ? "✓" : "✗"}</span>
                </div>
                <div className="flex items-center gap-2 p-3 hud-element rounded">
                  <div
                    className={`w-3 h-3 rounded-full status-indicator ${configurationStatus.googleMaps ? "bg-green-400" : "bg-yellow-400"}`}
                  ></div>
                  <MapPin className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-mono">MAPS {configurationStatus.googleMaps ? "✓" : "⚠"}</span>
                </div>
                <div className="flex items-center gap-2 p-3 hud-element rounded">
                  <div className="w-3 h-3 rounded-full bg-green-400 status-indicator"></div>
                  <Volume2 className="w-4 h-4 text-cyan-400" />
                  <span className="text-sm font-mono">VOICE SYN ✓</span>
                </div>
              </div>

              {!configurationStatus.openai && (
                <Alert className="mt-4 border-red-500/30 bg-red-900/20">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription className="font-mono">
                    [CRITICAL] AI CORE MODULE OFFLINE - OPENAI_API_KEY REQUIRED
                  </AlertDescription>
                </Alert>
              )}

              {!configurationStatus.serper && (
                <Alert className="mt-4 border-red-500/30 bg-red-900/20">
                  <Search className="h-4 w-4" />
                  <AlertDescription className="font-mono">
                    [WARNING] WEB SEARCH MODULE OFFLINE - SERPER_API_KEY REQUIRED
                  </AlertDescription>
                </Alert>
              )}
            </HolographicDisplay>
          </div>
        )}

        {/* Main Interface */}
        <div className="max-w-4xl mx-auto">
          {/* Central Energy Core */}
          <HolographicDisplay className="mb-8 p-8 relative">
            <HolographicScanner active={isProcessing || isListening} />
            <DataStream direction="horizontal" />

            <div className="text-center">
              {/* Energy Core Visualization */}
              <div className="relative mb-8 flex justify-center">
                <EnergyCore size={200} active={wakeWordDetected || isListening || isProcessing || isSpeaking} />

                {/* Central Status Icon */}
                <div className="absolute inset-0 flex items-center justify-center">
                  {isProcessing ? (
                    <Zap className="w-16 h-16 text-yellow-400 animate-spin" />
                  ) : isSpeaking ? (
                    <Volume2 className="w-16 h-16 text-purple-400 animate-pulse" />
                  ) : isListening ? (
                    <Mic className="w-16 h-16 text-blue-400 neon-glow" />
                  ) : isMuted ? ( // Show mute icon when muted
                    <VolumeX className="w-16 h-16 text-red-400" />
                  ) : (
                    <MicOff className="w-16 h-16 text-slate-400" />
                  )}
                </div>
              </div>

              {/* Status Text */}
              <div className="mb-6">
                <p className="text-lg text-cyan-300 mb-2 font-mono">
                  {isProcessing
                    ? "[PROCESSING] ANALYZING REQUEST..."
                    : isSpeaking
                      ? "[SPEAKING] TRANSMITTING RESPONSE..."
                      : isListening
                        ? "[LISTENING] VOICE INPUT ACTIVE"
                        : isMuted
                          ? "[MUTED] VOICE OUTPUT DISABLED" // New status for muted
                          : !networkStatus.online
                            ? "[ERROR] NETWORK CONNECTION REQUIRED"
                            : !networkStatus.speechAvailable
                              ? "[ERROR] SPEECH RECOGNITION UNAVAILABLE"
                              : configurationStatus.openai
                                ? '[READY] SAY "JARVIS" TO ACTIVATE'
                                : "[STANDBY] AI CORE CONFIGURATION REQUIRED"}
                </p>

                {/* System Status Indicators */}
                <div className="flex justify-center gap-8 text-sm font-mono">
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full status-indicator ${wakeWordDetected ? "bg-green-400 animate-pulse" : isWakeWordActiveRef.current ? "bg-green-600" : "bg-slate-600"}`}
                    ></div>
                    <span>WAKE WORD</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full status-indicator ${isListening ? "bg-blue-400 animate-pulse" : "bg-slate-600"}`}
                    ></div>
                    <span>LISTENING</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full status-indicator ${isProcessing ? "bg-yellow-400 animate-pulse" : "bg-slate-600"}`}
                    ></div>
                    <span>PROCESSING</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-2 h-2 rounded-full status-indicator ${isSpeaking ? "bg-purple-400 animate-pulse" : "bg-slate-600"}`}
                    ></div>
                    <span>SPEAKING</span>
                  </div>
                </div>
              </div>
            </div>
          </HolographicDisplay>

          {/* User Speech Display */}
          {userSpeech && (
            <HolographicDisplay className="mb-4 p-6">
              <div className="text-lg text-blue-300 font-mono">
                [USER] <GlitchText>{userSpeech}</GlitchText>
              </div>
            </HolographicDisplay>
          )}

          {/* AI Response Display */}
          {aiResponse && (
            <HolographicDisplay className="mb-8 p-6">
              <div className="text-lg text-green-300 font-mono">
                [JARVIS] <GlitchText>{aiResponse}</GlitchText>
              </div>
            </HolographicDisplay>
          )}

          {/* Conversation History */}
          {conversationHistory.length > 0 && (
            <HolographicDisplay className="mb-8 p-6">
              <h3 className="text-lg font-semibold text-cyan-400 font-mono mb-4">[CONVERSATION LOG]</h3>
              {conversationHistory.map((message, index) => (
                <div
                  key={index}
                  className={`mb-2 font-mono ${message.role === "user" ? "text-blue-300" : "text-green-300"}`}
                >
                  [{message.role.toUpperCase()}] {message.content}
                </div>
              ))}
            </HolographicDisplay>
          )}

          {/* Listening Toggle Button */}
          <div className="text-center">
            <button
              className={`px-6 py-3 rounded-full font-mono text-lg transition-colors duration-300
                ${isListening ? "bg-red-700 hover:bg-red-600 text-white" : "bg-blue-700 hover:bg-blue-600 text-white"}`}
              onClick={handleListeningToggle}
              disabled={isProcessing || isSpeaking}
            >
              {isListening ? "STOP LISTENING" : "START LISTENING"}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}
