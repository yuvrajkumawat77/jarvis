"use client"

import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { ExternalLink, Key, MapPin, CreditCard, Search, Globe } from "lucide-react"

export default function SetupGuide() {
  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      {/* Serper API Setup */}
      <Card className="bg-slate-800/50 border-blue-500/30 backdrop-blur-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <Search className="w-5 h-5 text-blue-400" />
          <h2 className="text-xl font-semibold text-blue-400">Get Your Serper API Key (Web Search)</h2>
        </div>

        <div className="space-y-4">
          <Alert className="border-blue-500/30 bg-blue-900/20">
            <Globe className="h-4 w-4" />
            <AlertDescription>
              <strong>Free Tier:</strong> 2,500 free searches per month - perfect for personal use!
            </AlertDescription>
          </Alert>

          <div className="grid gap-4">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 1: Sign Up for Serper</h3>
              <p className="text-slate-300">
                Create a free account at Serper.dev - no credit card required for the free tier.
              </p>
              <Button
                onClick={() => window.open("https://serper.dev", "_blank")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Sign Up at Serper.dev
              </Button>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 2: Get Your API Key</h3>
              <p className="text-slate-300">After signing up, go to your dashboard and copy your API key.</p>
              <Button
                onClick={() => window.open("https://serper.dev/dashboard", "_blank")}
                className="bg-green-600 hover:bg-green-700"
              >
                <Key className="w-4 h-4 mr-2" />
                Get API Key
              </Button>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 3: Add to Vercel</h3>
              <p className="text-slate-300">Add your API key as an environment variable in your Vercel project:</p>
              <div className="bg-slate-900 p-3 rounded font-mono text-sm">
                <span className="text-blue-400">SERPER_API_KEY</span>
                <span className="text-slate-400"> = </span>
                <span className="text-green-400">your_serper_api_key_here</span>
              </div>
            </div>
          </div>
        </div>
      </Card>

      {/* Google Maps API Setup */}
      <Card className="bg-slate-800/50 border-cyan-500/30 backdrop-blur-sm p-6">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="w-5 h-5 text-cyan-400" />
          <h2 className="text-xl font-semibold text-cyan-400">Get Your Google Maps API Key</h2>
        </div>

        <div className="space-y-4">
          <Alert className="border-cyan-500/30 bg-cyan-900/20">
            <MapPin className="h-4 w-4" />
            <AlertDescription>
              <strong>Free Tier Available:</strong> Google Maps provides $200/month in free credits, which covers
              thousands of requests for personal use.
            </AlertDescription>
          </Alert>

          <div className="grid gap-4">
            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 1: Create Google Cloud Account</h3>
              <p className="text-slate-300">
                Go to Google Cloud Console and create a free account (requires credit card for verification, but won't
                be charged unless you exceed free limits).
              </p>
              <Button
                onClick={() => window.open("https://console.cloud.google.com/", "_blank")}
                className="bg-blue-600 hover:bg-blue-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Open Google Cloud Console
              </Button>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 2: Create a New Project</h3>
              <p className="text-slate-300">
                Create a new project called "JARVIS Assistant" or similar to organize your API usage.
              </p>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 3: Enable Required APIs</h3>
              <p className="text-slate-300">Enable these APIs in your project:</p>
              <ul className="list-disc list-inside text-slate-300 ml-4 space-y-1">
                <li>Places API (for finding locations)</li>
                <li>Directions API (for navigation)</li>
                <li>Geocoding API (for address conversion)</li>
              </ul>
              <div className="flex gap-2 flex-wrap">
                <Button
                  onClick={() =>
                    window.open("https://console.cloud.google.com/apis/library/places-backend.googleapis.com", "_blank")
                  }
                  className="bg-green-600 hover:bg-green-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Enable Places API
                </Button>
                <Button
                  onClick={() =>
                    window.open(
                      "https://console.cloud.google.com/apis/library/directions-backend.googleapis.com",
                      "_blank",
                    )
                  }
                  className="bg-green-600 hover:bg-green-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Enable Directions API
                </Button>
                <Button
                  onClick={() =>
                    window.open(
                      "https://console.cloud.google.com/apis/library/geocoding-backend.googleapis.com",
                      "_blank",
                    )
                  }
                  className="bg-green-600 hover:bg-green-700"
                >
                  <ExternalLink className="w-4 h-4 mr-2" />
                  Enable Geocoding API
                </Button>
              </div>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 4: Create API Key</h3>
              <p className="text-slate-300">
                Go to "Credentials" section and create a new API key. Restrict it to the APIs you enabled for security.
              </p>
              <Button
                onClick={() => window.open("https://console.cloud.google.com/apis/credentials", "_blank")}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <ExternalLink className="w-4 h-4 mr-2" />
                Create API Key
              </Button>
            </div>

            <div className="space-y-3">
              <h3 className="text-lg font-semibold text-white">Step 5: Add to Vercel</h3>
              <p className="text-slate-300">
                Copy your API key and add it as an environment variable in your Vercel project settings:
              </p>
              <div className="bg-slate-900 p-3 rounded font-mono text-sm">
                <span className="text-cyan-400">GOOGLE_MAPS_API_KEY</span>
                <span className="text-slate-400"> = </span>
                <span className="text-green-400">your_google_maps_api_key_here</span>
              </div>
            </div>
          </div>

          <Alert className="border-yellow-500/30 bg-yellow-900/20">
            <CreditCard className="h-4 w-4" />
            <AlertDescription>
              <strong>Cost Estimate:</strong> With the free $200/month credit, you can make approximately:
              <ul className="list-disc list-inside mt-2 ml-4">
                <li>40,000 Places searches</li>
                <li>40,000 Geocoding requests</li>
                <li>40,000 Directions requests</li>
              </ul>
              Perfect for personal use!
            </AlertDescription>
          </Alert>
        </div>
      </Card>

      {/* Alternative Usage */}
      <Card className="bg-slate-800/50 border-green-500/30 backdrop-blur-sm p-6">
        <h3 className="text-lg font-semibold text-green-400 mb-3">Alternative: Use Without APIs</h3>
        <p className="text-slate-300 mb-4">Your JARVIS assistant works great even without these APIs! You still get:</p>
        <ul className="list-disc list-inside text-slate-300 space-y-1">
          <li>✅ AI conversations with OpenAI</li>
          <li>✅ Voice recognition and synthesis</li>
          <li>✅ Wake word detection</li>
          <li>✅ Basic question answering</li>
        </ul>
        <p className="text-slate-300 mt-4">
          Web search and Maps features will simply be disabled until you add the API keys - no errors or issues!
        </p>
      </Card>

      {/* Quick Setup Summary */}
      <Card className="bg-slate-800/50 border-purple-500/30 backdrop-blur-sm p-6">
        <h3 className="text-lg font-semibold text-purple-400 mb-3">🚀 Quick Setup Summary</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <h4 className="font-semibold text-white mb-2">For Web Search:</h4>
            <ol className="list-decimal list-inside text-slate-300 text-sm space-y-1">
              <li>Sign up at serper.dev (free)</li>
              <li>Copy your API key</li>
              <li>Add SERPER_API_KEY to Vercel</li>
            </ol>
          </div>
          <div>
            <h4 className="font-semibold text-white mb-2">For Google Maps:</h4>
            <ol className="list-decimal list-inside text-slate-300 text-sm space-y-1">
              <li>Create Google Cloud account</li>
              <li>Enable Maps APIs</li>
              <li>Create API key</li>
              <li>Add GOOGLE_MAPS_API_KEY to Vercel</li>
            </ol>
          </div>
        </div>
      </Card>
    </div>
  )
}
