"use client"

import type React from "react"

import { useEffect, useState } from "react"

// Particle System Component
export function ParticleField() {
  const [particles, setParticles] = useState<Array<{ id: number; left: number; delay: number }>>([])

  useEffect(() => {
    const particleArray = Array.from({ length: 50 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 10,
    }))
    setParticles(particleArray)
  }, [])

  return (
    <div className="particle-field">
      {particles.map((particle) => (
        <div
          key={particle.id}
          className="particle"
          style={{
            left: `${particle.left}%`,
            animationDelay: `${particle.delay}s`,
          }}
        />
      ))}
    </div>
  )
}

// Matrix Rain Effect
export function MatrixRain() {
  const [drops, setDrops] = useState<Array<{ id: number; left: number; delay: number; duration: number }>>([])

  useEffect(() => {
    const dropArray = Array.from({ length: 20 }, (_, i) => ({
      id: i,
      left: Math.random() * 100,
      delay: Math.random() * 5,
      duration: 3 + Math.random() * 2,
    }))
    setDrops(dropArray)
  }, [])

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {drops.map((drop) => (
        <div
          key={drop.id}
          className="absolute w-px bg-gradient-to-b from-cyan-400 via-cyan-300 to-transparent opacity-30"
          style={{
            left: `${drop.left}%`,
            height: "100px",
            animation: `matrix-rain ${drop.duration}s linear infinite`,
            animationDelay: `${drop.delay}s`,
          }}
        />
      ))}
    </div>
  )
}

// Holographic Display Component
export function HolographicDisplay({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`holographic-border scan-line ${className}`}>
      <div className="hologram-effect p-1">{children}</div>
    </div>
  )
}

// Energy Core Visualization
export function EnergyCore({ size = 200, active = false }: { size?: number; active?: boolean }) {
  return (
    <div className="relative flex items-center justify-center" style={{ width: size, height: size }}>
      {/* Outer Ring */}
      <div
        className={`absolute border-2 border-cyan-400 rounded-full ${active ? "energy-core" : ""}`}
        style={{ width: size, height: size }}
      />

      {/* Middle Ring */}
      <div
        className={`absolute border border-blue-400 rounded-full ${active ? "energy-core" : ""}`}
        style={{
          width: size * 0.7,
          height: size * 0.7,
          animationDelay: "1s",
          animationDirection: "reverse",
        }}
      />

      {/* Inner Core */}
      <div
        className={`absolute bg-gradient-to-r from-cyan-400 to-blue-500 rounded-full ${active ? "neon-glow" : ""}`}
        style={{ width: size * 0.3, height: size * 0.3 }}
      />

      {/* Quantum Field Effect */}
      {active && <div className="quantum-field absolute inset-0" />}
    </div>
  )
}

// HUD Status Bar
export function HUDStatusBar({
  label,
  value,
  maxValue = 100,
  color = "cyan",
}: {
  label: string
  value: number
  maxValue?: number
  color?: "cyan" | "green" | "red" | "yellow" | "purple"
}) {
  const percentage = (value / maxValue) * 100
  const colorClasses = {
    cyan: "from-cyan-400 to-cyan-600",
    green: "from-green-400 to-green-600",
    red: "from-red-400 to-red-600",
    yellow: "from-yellow-400 to-yellow-600",
    purple: "from-purple-400 to-purple-600",
  }

  return (
    <div className="hud-element p-3 rounded">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-mono text-cyan-300">{label}</span>
        <span className="text-sm font-mono text-white">
          {value}/{maxValue}
        </span>
      </div>
      <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
        <div
          className={`h-full bg-gradient-to-r ${colorClasses[color]} transition-all duration-500 relative`}
          style={{ width: `${percentage}%` }}
        >
          <div className="absolute inset-0 bg-white opacity-20 animate-pulse" />
        </div>
      </div>
    </div>
  )
}

// Circuit Board Pattern
export function CircuitPattern() {
  return (
    <div className="absolute inset-0 opacity-10 pointer-events-none">
      <svg width="100%" height="100%" className="tech-grid">
        <defs>
          <pattern id="circuit" x="0" y="0" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M0 20h40M20 0v40M10 10h20v20h-20z" stroke="rgba(0, 255, 255, 0.3)" strokeWidth="0.5" fill="none" />
            <circle cx="20" cy="20" r="2" fill="rgba(0, 255, 255, 0.5)" />
          </pattern>
        </defs>
        <rect width="100%" height="100%" fill="url(#circuit)" />
      </svg>
    </div>
  )
}

// Data Stream Visualization
export function DataStream({ direction = "horizontal" }: { direction?: "horizontal" | "vertical" }) {
  return (
    <div className={`absolute ${direction === "horizontal" ? "inset-x-0 h-px" : "inset-y-0 w-px"} pointer-events-none`}>
      <div className={`${direction === "horizontal" ? "data-stream h-full" : "data-stream w-full rotate-90"}`} />
    </div>
  )
}

// Glitch Text Effect
export function GlitchText({ children, className = "" }: { children: string; className?: string }) {
  return (
    <span className={`glitch-text ${className}`} data-text={children}>
      {children}
    </span>
  )
}

// Holographic Scanner
export function HolographicScanner({ active = false }: { active?: boolean }) {
  if (!active) return null

  return (
    <div className="absolute inset-0 pointer-events-none overflow-hidden">
      <div
        className="absolute inset-0 bg-gradient-to-b from-transparent via-cyan-400/20 to-transparent h-8 animate-pulse"
        style={{ animation: "holographic-scan 3s ease-in-out infinite" }}
      />
    </div>
  )
}
