import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { query, type = "search", test = false } = await request.json()

    // Check if API key is available
    if (!process.env.GOOGLE_MAPS_API_KEY) {
      console.warn("Google Maps API key is missing")
      return NextResponse.json({
        results:
          "Google Maps functionality is not available. Please add your GOOGLE_MAPS_API_KEY environment variable to enable location services.",
        available: false,
        error: "missing_api_key",
      })
    }

    // If this is a test request, just verify the API key works
    if (test) {
      try {
        const testResponse = await fetch(
          `https://maps.googleapis.com/maps/api/geocode/json?address=New+York&key=${process.env.GOOGLE_MAPS_API_KEY}`,
        )

        if (!testResponse.ok) {
          const errorText = await testResponse.text()
          console.error(`Google Maps API test failed: ${testResponse.status} - ${errorText}`)

          if (testResponse.status === 403) {
            return NextResponse.json({
              results: "Google Maps API key is invalid or restricted. Please check your API key and enabled APIs.",
              available: false,
              error: "invalid_key",
            })
          } else {
            return NextResponse.json({
              results: "Google Maps API test failed. Please check your configuration.",
              available: false,
              error: "api_error",
            })
          }
        }

        const testData = await testResponse.json()

        if (testData.status === "REQUEST_DENIED") {
          return NextResponse.json({
            results: "Google Maps API access denied. Please check your API key and billing settings.",
            available: false,
            error: "access_denied",
          })
        } else if (testData.status === "OVER_QUERY_LIMIT") {
          return NextResponse.json({
            results: "Google Maps API quota exceeded. Please check your usage limits.",
            available: false,
            error: "quota_exceeded",
          })
        }

        return NextResponse.json({
          results: "Google Maps API is working correctly.",
          available: true,
        })
      } catch (testError) {
        console.error("Google Maps API test error:", testError)
        return NextResponse.json({
          results: "Failed to test Google Maps API connection.",
          available: false,
          error: "connection_error",
        })
      }
    }

    let results = ""

    try {
      if (type === "search" || type === "places") {
        // Places API - Find places
        const placesResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/textsearch/json?query=${encodeURIComponent(query)}&key=${process.env.GOOGLE_MAPS_API_KEY}`,
        )

        if (!placesResponse.ok) {
          throw new Error(`Places API request failed: ${placesResponse.status}`)
        }

        const placesData = await placesResponse.json()

        if (placesData.status === "REQUEST_DENIED") {
          return NextResponse.json({
            results: "Google Maps API access denied. Please check your API key and enabled APIs.",
            available: false,
            error: "access_denied",
          })
        } else if (placesData.status === "OVER_QUERY_LIMIT") {
          return NextResponse.json({
            results: "Google Maps API quota exceeded. Please check your usage limits.",
            available: false,
            error: "quota_exceeded",
          })
        }

        if (placesData.results && placesData.results.length > 0) {
          const topResults = placesData.results.slice(0, 5)
          results = topResults
            .map((place: any) => {
              const rating = place.rating ? ` (Rating: ${place.rating}/5)` : ""
              const address = place.formatted_address || "Address not available"
              const status =
                place.business_status === "OPERATIONAL" ? "Open" : place.business_status || "Status unknown"
              return `${place.name}${rating} - ${address} - Status: ${status}`
            })
            .join("\n\n")
        } else {
          results = `No places found for "${query}". Try a different search term or location.`
        }
      } else if (type === "directions") {
        // Directions API
        const [origin, destination] = query.split(" to ")

        if (!origin || !destination) {
          return NextResponse.json({
            results: "Please provide directions in the format: 'from [origin] to [destination]'",
            error: "invalid_format",
          })
        }

        const directionsResponse = await fetch(
          `https://maps.googleapis.com/maps/api/directions/json?origin=${encodeURIComponent(origin)}&destination=${encodeURIComponent(destination)}&key=${process.env.GOOGLE_MAPS_API_KEY}`,
        )

        if (!directionsResponse.ok) {
          throw new Error(`Directions API request failed: ${directionsResponse.status}`)
        }

        const directionsData = await directionsResponse.json()

        if (directionsData.status === "REQUEST_DENIED") {
          return NextResponse.json({
            results: "Google Maps API access denied. Please check your API key and enabled APIs.",
            available: false,
            error: "access_denied",
          })
        }

        if (directionsData.routes && directionsData.routes.length > 0) {
          const route = directionsData.routes[0]
          const leg = route.legs[0]

          results = `Directions from ${leg.start_address} to ${leg.end_address}:\n\n`
          results += `Distance: ${leg.distance.text}\n`
          results += `Duration: ${leg.duration.text}\n\n`

          if (leg.steps && leg.steps.length > 0) {
            results += "Key directions:\n"
            leg.steps.slice(0, 5).forEach((step: any, index: number) => {
              const instruction = step.html_instructions.replace(/<[^>]*>/g, "") // Remove HTML tags
              results += `${index + 1}. ${instruction} (${step.distance.text})\n`
            })
          }
        } else {
          results = `No route found from "${origin}" to "${destination}". Please check the locations and try again.`
        }
      } else if (type === "nearby") {
        // Nearby search
        const [searchQuery, location] = query.split(" near ")

        if (!location) {
          return NextResponse.json({
            results: "Please provide location in the format: '[what you're looking for] near [location]'",
            error: "invalid_format",
          })
        }

        // First get coordinates for the location
        const geocodeResponse = await fetch(
          `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(location)}&key=${process.env.GOOGLE_MAPS_API_KEY}`,
        )

        const geocodeData = await geocodeResponse.json()

        if (!geocodeData.results || geocodeData.results.length === 0) {
          return NextResponse.json({
            results: `Could not find location: ${location}`,
            error: "location_not_found",
          })
        }

        const { lat, lng } = geocodeData.results[0].geometry.location

        // Now search for nearby places
        const nearbyResponse = await fetch(
          `https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=${lat},${lng}&radius=5000&keyword=${encodeURIComponent(searchQuery)}&key=${process.env.GOOGLE_MAPS_API_KEY}`,
        )

        const nearbyData = await nearbyResponse.json()

        if (nearbyData.results && nearbyData.results.length > 0) {
          const topResults = nearbyData.results.slice(0, 5)
          results = `Found ${searchQuery} near ${location}:\n\n`
          results += topResults
            .map((place: any) => {
              const rating = place.rating ? ` (${place.rating}/5 stars)` : ""
              const priceLevel = place.price_level ? ` - Price: ${"$".repeat(place.price_level)}` : ""
              const status = place.business_status === "OPERATIONAL" ? "Open" : place.business_status || ""
              return `${place.name}${rating}${priceLevel} - ${place.vicinity} ${status ? `- ${status}` : ""}`
            })
            .join("\n\n")
        } else {
          results = `No ${searchQuery} found near ${location}. Try a different search or location.`
        }
      }

      return NextResponse.json({
        results,
        type,
        available: true,
      })
    } catch (apiError) {
      console.error("Google Maps API error:", apiError)
      return NextResponse.json({
        results: "I encountered an error accessing Google Maps. Please try again later.",
        available: false,
        error: "api_error",
      })
    }
  } catch (error) {
    console.error("Maps API error:", error)
    return NextResponse.json({
      results: "I couldn't process your location request right now. Please try again.",
      available: false,
      error: "processing_error",
    })
  }
}
