import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { text } = await request.json()

    // Check if API key is available
    if (!process.env.ELEVENLABS_API_KEY) {
      console.log("ElevenLabs API key is missing, using browser speech synthesis fallback")
      return NextResponse.json({
        fallback: true,
        text: text,
        message: "Using browser text-to-speech (no API key configured)",
      })
    }

    // Using ElevenLabs API for text-to-speech
    const response = await fetch("https://api.elevenlabs.io/v1/text-to-speech/JBFqnCBsd6RMkjVDRZzb", {
      method: "POST",
      headers: {
        Accept: "audio/mpeg",
        "Content-Type": "application/json",
        "xi-api-key": process.env.ELEVENLABS_API_KEY,
      },
      body: JSON.stringify({
        text: text,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          stability: 0.5,
          similarity_boost: 0.5,
        },
      }),
    })

    if (!response.ok) {
      let errorMessage = `ElevenLabs API error (${response.status})`

      try {
        const errorData = await response.json()
        if (errorData.detail?.message) {
          if (
            errorData.detail.message.includes("unusual activity") ||
            errorData.detail.message.includes("Free Tier usage disabled")
          ) {
            errorMessage = "ElevenLabs free tier disabled due to unusual activity"
            console.warn("ElevenLabs free tier access disabled:", errorData.detail.message)
          } else if (errorData.detail.message.includes("quota")) {
            errorMessage = "ElevenLabs quota exceeded"
          } else {
            errorMessage = `ElevenLabs API error: ${errorData.detail.message}`
          }
        }
      } catch (parseError) {
        console.error("Failed to parse ElevenLabs error response:", parseError)
      }

      console.error(`ElevenLabs API request failed: ${response.status} - ${errorMessage}`)

      // Return fallback response for browser TTS
      return NextResponse.json({
        fallback: true,
        text: text,
        message: `${errorMessage}. Using browser text-to-speech.`,
        error: "elevenlabs_unavailable",
      })
    }

    const audioBuffer = await response.arrayBuffer()

    return new NextResponse(audioBuffer, {
      headers: {
        "Content-Type": "audio/mpeg",
      },
    })
  } catch (error) {
    console.error("Speech synthesis error:", error)

    // Return fallback response for browser TTS
    const { text } = await request.json().catch(() => ({ text: "Error occurred" }))
    return NextResponse.json({
      fallback: true,
      text: text,
      message: "ElevenLabs service unavailable. Using browser text-to-speech.",
      error: "service_error",
    })
  }
}
