import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, searchResults, history } = await request.json()

    // Check if API key is available
    if (!process.env.OPENAI_API_KEY) {
      console.warn("OpenAI API key is missing")
      return NextResponse.json({
        response: `I understand you said: "${message}". However, I'm not fully configured right now because my OpenAI API key is missing. To enable my AI capabilities, please add your OPENAI_API_KEY environment variable in your Vercel project settings.`,
        error: "missing_api_key",
      })
    }

    // Dynamic import to avoid loading AI SDK when API key is missing
    const { generateText } = await import("ai")
    const { openai } = await import("@ai-sdk/openai")

    let systemPrompt = `You are JARVIS, an advanced AI assistant. You are helpful, intelligent, and speak in a professional but friendly manner. Keep responses concise but informative.`

    if (searchResults) {
      systemPrompt += `\n\nHere is current information from the web that may be relevant to the user's query:\n${searchResults}\n\nUse this information to provide accurate, up-to-date responses.`
    }

    const messages = [{ role: "system", content: systemPrompt }, ...history, { role: "user", content: message }]

    const { text } = await generateText({
      model: openai("gpt-4o-mini"),
      messages: messages as any,
      maxTokens: 500,
      temperature: 0.7,
    })

    return NextResponse.json({ response: text })
  } catch (error) {
    console.error("Chat API error:", error)

    // Provide helpful error messages based on the error type
    let errorMessage = "I apologize, but I encountered an error generating a response."

    if (error instanceof Error) {
      if (error.message.includes("API key") || error.message.includes("apiKey")) {
        errorMessage =
          "I'm not properly configured right now. Please check that your OpenAI API key is set correctly in your environment variables."
      } else if (error.message.includes("quota")) {
        errorMessage = "I've reached my usage limit. Please check your OpenAI account quota."
      } else if (error.message.includes("network") || error.message.includes("fetch")) {
        errorMessage = "I'm having trouble connecting to my AI service. Please try again in a moment."
      }
    }

    return NextResponse.json({
      response: errorMessage,
      error: "api_error",
    })
  }
}
