import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { query, type = "search" } = await request.json() // Added type parameter

    // Check if API key is available
    if (!process.env.SERPER_API_KEY) {
      console.warn("Serper API key is missing, skipping search")
      return NextResponse.json({
        results:
          "Web search is not available right now. To enable web search, please add your SERPER_API_KEY environment variable.",
        available: false,
      })
    }

    let apiUrl = ""
    let requestBody: any = { q: query, num: 5 }
    let results = ""

    if (type === "news") {
      apiUrl = "https://google.serper.dev/news"
      requestBody = { q: query, num: 5 } // News endpoint also uses 'q' for query
    } else {
      // Default to general search
      apiUrl = "https://google.serper.dev/search"
      requestBody = { q: query, num: 5 }
    }

    const response = await fetch(apiUrl, {
      method: "POST",
      headers: {
        "X-API-KEY": process.env.SERPER_API_KEY,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(requestBody),
    })

    if (!response.ok) {
      const errorText = await response.text()
      console.error(`Serper API request failed: ${response.status} - ${errorText}`)

      if (response.status === 401) {
        return NextResponse.json({
          results: "Web search API key is invalid. Please check your SERPER_API_KEY.",
          available: false,
          error: "invalid_key",
        })
      } else if (response.status === 429) {
        return NextResponse.json({
          results: "Web search quota exceeded. Please check your Serper API usage.",
          available: false,
          error: "quota_exceeded",
        })
      } else {
        return NextResponse.json({
          results: "Web search service is temporarily unavailable. Please try again later.",
          available: false,
          error: "service_error",
        })
      }
    }

    const data = await response.json()

    // Format search results based on type
    if (type === "news" && data.news) {
      results = data.news
        .slice(0, 3)
        .map((item: any) => `${item.title}: ${item.snippet} (Source: ${item.source})`)
        .join("\n\n")
      if (results === "") {
        results = `No news articles found for "${query}".`
      }
    } else if (data.organic) {
      results = data.organic
        .slice(0, 3)
        .map((result: any) => `${result.title}: ${result.snippet}`)
        .join("\n\n")
      if (results === "") {
        results = `No search results found for "${query}". Try a different search term.`
      }
    } else {
      results = `No relevant information found for "${query}".`
    }

    return NextResponse.json({
      results,
      available: true,
    })
  } catch (error) {
    console.error("Search API error:", error)
    return NextResponse.json({
      results: "I couldn't search the web right now due to a technical error. Please try again later.",
      available: false,
      error: "technical_error",
    })
  }
}
