import { type NextRequest, NextResponse } from "next/server"

export async function GET(request: NextRequest) {
  try {
    // Check which API keys are available
    const config = {
      openai: !!process.env.OPENAI_API_KEY,
      serper: !!process.env.SERPER_API_KEY,
      googleMaps: !!process.env.GOOGLE_MAPS_API_KEY,
      elevenlabs: !!process.env.ELEVENLABS_API_KEY,
    }

    return NextResponse.json(config)
  } catch (error) {
    console.error("Config check error:", error)
    return NextResponse.json({
      openai: false,
      serper: false,
      googleMaps: false,
      elevenlabs: false,
    })
  }
}
